Python 3; standard library only. Exact fixtures from the November 8 Codex recording.

cd before
python3 -m unittest -v
Expected: 3 failing tests.

cd ../after
python3 -m unittest -v
Expected: 3 passing tests.
python3 penalty.py
Expected penalty: 0.6475.

The test files are identical in both folders.
